<!DOCTYPE html>
<html>
	<head>
 <?php include __DIR__ . '/components/header.php';?>

		<title>Thank you For Submitting Your Details </title>
		<meta name="description" content="#">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- Event snippet for MICA_LP conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-17834744994/p3CICIHzh9kbEKK5orhC'});
</script>
	</head>
	<body>
		<?php include "navbar.php"; ?>
		<!-- <script>fbq('track', 'Lead');</script>
		<script>
			// Start downloading the brochure and redirect after a delay
			setTimeout(function () {
				downloadBrochure();
				setTimeout(function () {
					window.location.href = 'https://distanceeducationschool.com/?utm_source=Google&utm_campaign=MBA_LP&messageText=.....';
				}, 3000); // Adjust the delay time (in milliseconds) as needed for the download
			}, 1000); // Delay before starting the download
		</script> -->
		
		<div class="thanku">
			<br>
			<div class="container">
				<div class="header">

					<br>
					<center>
						<img src="assets/img/submission-confirm.gif">
					</center>
					<center><h1 style="color:#000;"><strong>THANK YOU !</strong></h1></center>
					<center><h4><strong>Your Submission has been Received!</strong></h4></center>
					<br>
					<div class="button">
						<a href="https://mica.distanceeducationschool.in/"><center>	<button type="button" style="padding: 10px; border: 1px solid black; background-color:#002B5C; color: #fff; font-weight:bold;">For More Information Kindly Visit Here</button></center></a>
					</div><!--end of card-->
				</div><!--end of container-->
				<br>
			</div>
		</div><!--end of thanku-->
		 <?php include __DIR__ . '/components/footer.php';?>

		 <script>
      function openPopup(popupId) {
        document.getElementById(popupId).style.display = 'flex';
      }

      // Function to close a popup
      function closePopup(popupId) {
        document.getElementById(popupId).style.display = 'none';
      }

      // Add event listeners for all "Enquire Now" buttons
      const enquireButtons = document.querySelectorAll('.enquireNowBtn');
      enquireButtons.forEach(function (button) {
        button.addEventListener('click', function () {
          openPopup('enquirePopup');
        });
      });

      // Add event listeners for all "Download Brochure" buttons
      const brochureButtons = document.querySelectorAll('.downloadBrochureBtn');
      brochureButtons.forEach(function (button) {
        button.addEventListener('click', function () {
          openPopup('brochurePopup');
        });
      });
   </script>
   
	</body>
</html>