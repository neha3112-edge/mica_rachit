
     // JavaScript to handle accordion toggle
    //  document.querySelectorAll('.accordion-header').forEach(header => {
    //     header.addEventListener('click', () => {
    //         const content = header.nextElementSibling;
    //         const isOpen = content.style.display === 'block';

    //         // Close all open accordions
    //         document.querySelectorAll('.accordion-content').forEach(c => c.style.display = 'none');

    //         // Toggle the current accordion
    //         if (!isOpen) {
    //             content.style.display = 'block';
    //         }
    //     });
    // });

  //End on scroll popup

  